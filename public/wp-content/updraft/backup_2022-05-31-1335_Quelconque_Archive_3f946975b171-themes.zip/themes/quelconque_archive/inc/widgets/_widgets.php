<?php
/**
 *	Chargement des fichiers fils sous la nomenclature
 *	widgets-slug.php
 */

dh_require_multiple(dirname(__FILE__), [
	'widgets-dh-social.php',
]);