<?php

/**
 *	Chargement des fichiers fils sous la nomenclature
 *	cpts-slug.php
 *  "slug" = nom au singulier, exemples : article, evenement...
 */

/*

dh_require_multiple(dirname(__FILE__), [
	'cpts-slug.php',
]);

*/