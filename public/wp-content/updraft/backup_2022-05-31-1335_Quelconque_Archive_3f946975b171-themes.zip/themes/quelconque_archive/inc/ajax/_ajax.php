<?php
/**
 *	Chargement des fichiers fils sous la nomenclature
 *	ajax-slug.php
 */
dh_require_multiple(dirname(__FILE__), [
	//'ajax-slug.php',
]);