<?php

/**
 *	Chargement des fichiers fils sous la nomenclature
 *	metas-slug.php
 */

/*
dh_require_multiple(dirname(__FILE__), [
	'metas-slug.php',
]);

*/