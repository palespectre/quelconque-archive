<?php

namespace OXI_IMAGE_HOVER_PLUGINS\Modules\Magnifier\Admin;

/**
 * Description of Effects1
 *
 * @author biplob
 */
use OXI_IMAGE_HOVER_PLUGINS\Modules\Magnifier\Modules as Modules;
use OXI_IMAGE_HOVER_PLUGINS\Classes\Controls as Controls;

class Effects1 extends Modules {
    
     

}
