<?php

namespace OXI_IMAGE_HOVER_PLUGINS\Modules\Square\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_IMAGE_HOVER_PLUGINS\Modules\Square\Modules as Modules;

class Effects1 extends Modules {

    public function register_effects() {
        
    }

}
