<?php

namespace OXI_IMAGE_HOVER_PLUGINS\Modules\Button\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_IMAGE_HOVER_PLUGINS\Modules\Button\Modules as Modules;

class Effects1 extends Modules {
    
}
