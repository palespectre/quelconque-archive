<?php

namespace OXI_IMAGE_HOVER_PLUGINS\Modules\General\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_IMAGE_HOVER_PLUGINS\Modules\General\Modules as Modules;

class Effects17 extends Modules {

    public function register_effects() {
        
    }

}
