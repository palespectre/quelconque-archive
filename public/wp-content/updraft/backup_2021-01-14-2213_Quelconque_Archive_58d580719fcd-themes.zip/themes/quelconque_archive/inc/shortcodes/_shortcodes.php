<?php

/**
 *	Chargement des fichiers fils sous la nomenclature
 *	shortcodes-slug.php
 */

/*
dh_require_multiple(dirname(__FILE__), [
	'shortcodes-slug.php',
]);

*/