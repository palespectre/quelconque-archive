<?php

/**
 *	Chargement des fichiers fils sous la nomenclature
 *	taxonomies-slug.php
 */

/*
dh_require_multiple(dirname(__FILE__), [
	'taxonomies-slug.php',
]);

*/